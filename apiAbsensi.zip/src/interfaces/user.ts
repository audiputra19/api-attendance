export interface User {
    nik: number;
    pass: string;
    email: string;
}