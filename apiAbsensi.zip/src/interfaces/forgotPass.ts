export interface ForgotPass {
    nik: number;
    nama: string;
}